export { default } from './AlertDocumentUpdates';
