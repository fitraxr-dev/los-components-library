export { default } from './AlertDifferentData';
