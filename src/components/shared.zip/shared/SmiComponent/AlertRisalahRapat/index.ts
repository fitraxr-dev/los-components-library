export { default } from './AlertRisalahRapat';
