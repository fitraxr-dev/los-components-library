'use client';
import { useCallback, useMemo } from 'react';

import { useTheme } from '@mui/material';
import MuiSvgIcon from '@mui/material/SvgIcon';

import type { IconProps } from './types';

// Cache for loaded icons to prevent repeated require calls
const iconCache = new Map<string, any>();

const Icon = ({
  iconName,
  textVariant = 'body1',
  sx = {},
}: IconProps) => {
  const theme = useTheme();

  const loadIcon = useCallback((name: string) => {
    // Handle empty or undefined icon names
    if (!name || name.trim() === '') {
      return null;
    }

    // Check cache first
    if (iconCache.has(name)) {
      return iconCache.get(name);
    }

    try {
      const icon = require(`/public/icons/${name}.svg`).default;
      iconCache.set(name, icon);
      return icon;
    } catch (error) {
      // Only log error once per missing icon
      if (!iconCache.has('image-not-found')) {
        console.error('Error loading icon:', error);
        try {
          const fallbackIcon = require('/public/icons/image-not-found.svg').default;
          iconCache.set('image-not-found', fallbackIcon);
          iconCache.set(name, fallbackIcon);
          return fallbackIcon;
        } catch (fallbackError) {
          console.error('Error loading fallback icon:', fallbackError);
          // Return null to prevent further errors
          iconCache.set(name, null);
          return null;
        }
      } else {
        const fallbackIcon = iconCache.get('image-not-found');
        iconCache.set(name, fallbackIcon);
        return fallbackIcon;
      }
    }
  }, []);

  const IconComponent = useMemo(() => {
    if (!iconName) return null;
    return loadIcon(iconName);
  }, [iconName, loadIcon]);

  // Don't render if no icon component is available
  if (!IconComponent) {
    return null;
  }

  return (
    <MuiSvgIcon
      sx={{
        fill: 'none',
        fontSize: theme.typography[textVariant].fontSize,
        ...sx,
      }}
      inheritViewBox
      component={IconComponent}
    />
  );
};

export default Icon;
