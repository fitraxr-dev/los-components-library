export { default } from './RichText';
