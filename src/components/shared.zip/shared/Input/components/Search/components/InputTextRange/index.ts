export { default } from './InputTextRange';
