export { default } from './InputText';
