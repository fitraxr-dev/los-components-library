export { default } from './InputNumber';
