export { default } from './InputVirtualAccount';
