export { default } from './TableExposureGroup';
