export { default } from './SectionTitleFacilites';
