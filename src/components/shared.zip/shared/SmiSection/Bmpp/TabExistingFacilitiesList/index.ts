export { default } from './TabExistingFacilitiesList';
