export { default } from './TabProposedFacilitiesList';
