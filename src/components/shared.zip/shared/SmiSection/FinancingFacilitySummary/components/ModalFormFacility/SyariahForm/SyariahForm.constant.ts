export const validation: MasintonValidation = {
};
