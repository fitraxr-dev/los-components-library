export const AlIjarahFormData: MasintonForm = {

  currency_facility_value: {
    error: false,
    errorMessage: '',
    value: 'IDR',
  },
  currency_ujroh_value: {
    error: false,
    errorMessage: '',
    value: 'IDR',
  },
  exchange_rate_facility_value: {
    error: false,
    errorMessage: '',
    value: '1',
  },
  exchange_rate_ujroh: {
    error: false,
    errorMessage: '',
    value: '1',
  },
  expected_profit: {
    error: false,
    errorMessage: '',
    value: '',
  },
  facility_value: {
    error: false,
    errorMessage: '',
    value: '',
  },
  facility_value_idr: {
    error: false,
    errorMessage: '',
    value: '',
  },
  financing_period: {
    error: false,
    errorMessage: '',
    value: '',
  },
  government_mandate: {
    error: false,
    errorMessage: '',
    value: '',
  },
  ijarah_object: {
    error: false,
    errorMessage: '',
    value: '',
  },
  remarks: {
    error: false,
    errorMessage: '',
    value: '',
  },
  ujroh_payment_period: {
    error: false,
    errorMessage: '',
    value: '',
  },
  ujroh_review_period: {
    error: false,
    errorMessage: '',
    value: '',
  },
  ujroh_review_type: {
    error: false,
    errorMessage: '',
    value: '',
  },
  ujroh_value: {
    error: false,
    errorMessage: '',
    value: '',
  },
  ujroh_value_idr: {
    error: false,
    errorMessage: '',
    value: '',
  },

};
