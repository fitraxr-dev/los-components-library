export { default } from './ModalDetailFacility';
