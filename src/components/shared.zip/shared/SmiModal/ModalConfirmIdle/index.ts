export { default } from './ModalConfirmIdle';
