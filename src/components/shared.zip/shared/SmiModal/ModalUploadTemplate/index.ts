export { default } from './ModalUploadTemplate';
