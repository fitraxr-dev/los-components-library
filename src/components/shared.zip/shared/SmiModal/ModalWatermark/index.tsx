export { default } from './ModalWatermark';
