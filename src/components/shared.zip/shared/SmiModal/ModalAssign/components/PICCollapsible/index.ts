export { default } from './PICCollapsible';
