export { default } from './ModalErrorUploadTemplate';
