export { default } from './ModalUploadDocument';
