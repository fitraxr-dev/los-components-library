'use client';

import Modules from '@/enums/Modules';
import useGetParameterList from '@/hooks/services/useGetParameterList';

import Currency from '../Currency/Currency';

import type { TCurrencyProps } from './CurrencyForm.types';


const CurrencyFormWithoutKurs = ({ initialProps, idrProps, disabled }: TCurrencyProps) => {
  const { data: currencyDropdownList } = useGetParameterList(Modules.CURRENCY, {
    label: 'value1',
    rate: 'value2',
    value: 'key',
  });

  return (
    <>
      {/* Main Currency Input */}
      <Currency
        isMandatory={initialProps?.isMandatory ?? false}
        currencyList={currencyDropdownList}
        label={initialProps?.label || ''}
        placeholder={initialProps?.placeholder || ''}
        containerSx={{ flex: 1 }}
        value={{ currency: initialProps?.currency || '', value: initialProps?.value }}
        onChange={initialProps?.onChange}
        onCurrencyChange={initialProps?.onCurrencyChange}
        error={initialProps?.error ?? false}
        helperText={initialProps?.errorMessage ?? ''}
        disabled={disabled}
      />

      {initialProps?.currency !== 'IDR' && (
        <Currency
          currencyList={currencyDropdownList}
          label={`${initialProps?.label} (dalam Rp)`}
          placeholder={`${initialProps?.label} (dalam Rp)`}
          containerSx={{ flex: 1 }}
          value={{ currency: 'IDR', value: idrProps?.value }}
          disabled
          error={idrProps?.error ?? false}
          helperText={idrProps?.errorMessage ?? ''}
        />
      )}
    </>
  );
};

export default CurrencyFormWithoutKurs;
