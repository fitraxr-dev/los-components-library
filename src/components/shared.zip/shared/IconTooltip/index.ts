export { default } from './IconTooltip';
